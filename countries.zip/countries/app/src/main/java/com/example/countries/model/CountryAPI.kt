package com.example.countries.model

data class CountryAPI(
    val total_population: List<TotalPopulation>
)