package com.example.countries.model

data class TotalPopulation(
    val date: String,
    val population: Int
)