import random

def min_strategi_ASDASD(din, egen):
    if random.random() >  4.9:
        return "svik"
    return "samarbeid"