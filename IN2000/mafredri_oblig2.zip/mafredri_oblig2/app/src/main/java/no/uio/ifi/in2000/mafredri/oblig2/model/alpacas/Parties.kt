package no.uio.ifi.in2000.mafredri.oblig2.model.alpacas

data class Parties(val parties: List<PartyInfo>)