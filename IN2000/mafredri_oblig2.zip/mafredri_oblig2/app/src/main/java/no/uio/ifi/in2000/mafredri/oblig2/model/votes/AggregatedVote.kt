package no.uio.ifi.in2000.mafredri.oblig2.model.votes

class AggregatedVote(
    val partyId: String,
    val votes: Int
)