package no.uio.ifi.in2000.mafredri.oblig2.model.votes

data class IndividualVote(val id: String)
