package no.uio.ifi.in2000.mafredri.oblig2.model.votes

data class PartiesVote(val parties: List<AggregatedVote>)
