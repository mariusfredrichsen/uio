package no.uio.ifi.in2000.mafredri.oblig2.model.votes

data class PartyVote(
    val name: String,
    val votes: Int
)