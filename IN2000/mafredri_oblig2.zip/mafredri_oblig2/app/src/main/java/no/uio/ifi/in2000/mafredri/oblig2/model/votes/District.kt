package no.uio.ifi.in2000.mafredri.oblig2.model.votes

enum class District {
    ONE,
    TWO,
    THREE
}